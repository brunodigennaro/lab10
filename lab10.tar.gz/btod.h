/*  Bruno DiGennaro 
	CPSC 1110 001; Fall 2022
	October 30, 2022
	Binary to decimal and decimal to binary conversion using two functions
*/

#ifndef BTOD_H
#define BTOD_H
#include <stdio.h>
#include <string.h> 
#include <math.h> 

int btod(int size, char inputBin[size]);

#endif