/*  Bruno DiGennaro 
	CPSC 1110 001; Fall 2022
	October 30, 2022
	Binary to decimal and decimal to binary conversion using two functions
*/

#ifndef DTOB_H
#define DTOB_H
#include <stdio.h>
#include <string.h> 
#include <math.h> 

int dtob(int inputDec);

#endif